class ResultConstants:
    NO_AUTHOR = 'No author available'
    NO_YEAR = 'No year available'
    NO_PDF = 'No PDF available'
    NO_DOI = 'No DOI available'
    NO_CITE_COUNT = 'No cite count available'
